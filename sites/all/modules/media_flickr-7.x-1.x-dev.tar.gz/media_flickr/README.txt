
Readme for Media: Flicker

The Media: Flickr module allows editors to choose Flickr photos within the
Media browser, both for fields and withing WYSIWYG. It requires the Media
module, available at http://drupal.org/project/media.

To use it, enable the Media module. You'll also need to apply for a Flickr API
key, from http://www.flickr.com/services/api/keys, which you will paste into
the settings page at /admin/configure/media/media_flickr.

After that, editors will be able to paste a URL or the embed code for a Flickr
Photo into the browser, and it will be displayed automatically at the desired
size.
